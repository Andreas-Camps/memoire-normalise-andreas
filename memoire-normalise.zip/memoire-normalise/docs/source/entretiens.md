

### Entretiens

Une logique de mise en forme spécifique est proposée pour les retranscriptions d’entretiens. Le contenu peut être structuré ainsi :
```md
**Votre nom** **Votre question**

**Nom de la personne interview·ée** Sa réponse

**VN** **Votre 2e question (VN sont vos initiales)**

**PI** Sa 2e réponse (PI sont ses initiales)
```
