

Bravo ! Vous êtes arrivé⋅e à la dernière page de cette documentation.

## Mise en ligne et publication

Une fois terminé le processus d’édition sur un serveur local, le document peut être mis en ligne sur un serveur web de production (le serveur de l’ÉSAD Pyrénées ou un compte étudiant hébergé par Alwaysdata – [me demander](mailto:julien.bidoret@esad-pyrenees.fr)). Il faut alors s’assurer que le serveur est bien capable de servir le site via une version de PHP supérieure à 8.0 (sur Alwaysdata, [voir ici](https://admin.alwaysdata.com/environment/)).

Le lien « Imprimer », présent dans le fichier `index.php` peut être supprimé pour ne conserver que le seul « Télécharger ».

## Aller plus loin


* [Étendre et détourner l’outil](extend.md)