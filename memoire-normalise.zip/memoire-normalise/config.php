<?php

// Le titre du document
$title = "AI VS Design Graphique"; // &nbsp; = espace insécable
// Le sous-titre éventuel du document
$subtitle = "";
// Votre nom
$name = "Andréas Camps";
// L’année, par ex. : 2021 – 2022"
$year = "2022 - 2023" ;
// Votre diplôme, par ex. : DNA Design
$diploma = "DNSEP Design";
// Le mention du siplôme, par ex. : Mention Design graphique Multimédia
$mention = "Mention Design graphique Multimédia";
// Votre pôle éventuel, par ex. : Pôle Nouveaux médias
$pole = "Pôle Nouveaux médias";
// Le nom du fichier pdf généré, par ex. : url_du_document.pdf
$pdf = "document.pdf";

$parts = [

  [
    "title" => "Introduction",
    "file" => "text/1.intro.md",
    "template" => "default"
  ],
  [
    "title" => "Qu’est-ce qu’une IA ?",
    "file" => "text/2.questcequuneia.md",
    "template" => "default"
  ],
  [
    "title" => "Promptologie",
    "file" => "text/3.promptologie.md",
    "template" => "default"
  ],
  [
    "title" => "Usage",
    "file" => "text/4.usage.md",
    "template" => "default"
  ],
  [
    "title" => "Outils",
    "file" => "text/outils.md",
    "template" => "default"
  ],
  [
    "title" => "Conclusion",
    "file" => "text/5.conclusion.md",
    "template" => "default"
  ],
  [
    "title" => "Annexes",
    "file" => "text/6.annexes.md",
    "template" => "appendices"
  ],
  [
    "title" => "Glossaire",
    "file" => "text/8.glossaire.md",
    "template" => "references"
  ],
  [
    "title" => "Références",
    "file" => "text/9.references.md",
    "template" => "references"
  ],
  [
    "title" => "Remerciements",
    "file" => "text/10.remerciements.md",
    "template" => "thanks"
  ]
];